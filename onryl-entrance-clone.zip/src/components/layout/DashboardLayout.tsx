import { SideNav } from './SideNav';
import { Sun, Moon, User, BellRing, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface DashboardLayoutProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
}

export function DashboardLayout({ children, title, subtitle }: DashboardLayoutProps) {
  return (
    <div className="min-h-screen bg-[hsl(var(--entrance-bg))] text-[hsl(var(--entrance-text-primary))] flex">
      <SideNav />

      <div className="flex-1 flex flex-col">
        <header className="h-16 border-b border-[hsl(var(--entrance-border))] flex items-center justify-between px-6">
          <div className="flex items-center">
            {title && (
              <div>
                <h1 className="text-xl font-semibold">{title}</h1>
                {subtitle && <p className="text-sm text-[hsl(var(--entrance-text-secondary))]">{subtitle}</p>}
              </div>
            )}
          </div>

          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="rounded-full">
              <HelpCircle size={18} className="text-[hsl(var(--entrance-text-secondary))]" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full">
              <BellRing size={18} className="text-[hsl(var(--entrance-text-secondary))]" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full">
              <Sun size={18} className="text-[hsl(var(--entrance-text-secondary))]" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full">
              <User size={18} className="text-[hsl(var(--entrance-text-secondary))]" />
            </Button>
          </div>
        </header>

        <main className="flex-1 p-6 overflow-auto bg-[hsl(var(--entrance-bg))]">{children}</main>
      </div>
    </div>
  );
}
